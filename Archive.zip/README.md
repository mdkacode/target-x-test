Target-x test

```
npm install
```

```
npm run start
```
