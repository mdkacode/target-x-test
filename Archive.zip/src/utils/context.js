import React from 'react'

const NotesContext = React.createContext()

export default NotesContext
